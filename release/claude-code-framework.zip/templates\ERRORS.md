<!-- version: 1.0 | updated: YYYY-MM-DD -->
# Errors — Knowledge Base

### [Short label]
**Pattern:** What the error looks like (message, symptom, behavior)
**Cause:** What triggers it
**Fix:** What resolves it
