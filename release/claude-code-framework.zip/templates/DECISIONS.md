<!-- version: 1.0 | updated: YYYY-MM-DD -->
# Decisions

## YYYY-MM-DD: [Decision title]
- **What:** [What was decided]
- **Why:** [Why this was chosen]
- **Alternatives:** [What else was considered]
