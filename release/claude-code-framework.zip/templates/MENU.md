<!-- version: 1.0 | updated: YYYY-MM-DD -->
# Menu

1. **Save progress** — Write current work to all docs files so nothing is lost
2. **Run tests** — Execute all test scripts and show results
3. **Run project** — Install dependencies, build, and start the project
---
?. **Framework Help** — Show an introduction and overview of the framework
