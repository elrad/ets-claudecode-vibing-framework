<!-- version: 1.0 | updated: YYYY-MM-DD -->
# Specification

## Project: [Project Name]

[Describe what this project does]

### Key Features
- [Feature 1]
- [Feature 2]

### How It Works
- [Brief description of architecture]

### Requirements
- [Requirement 1]
- [Requirement 2]
